﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkpoint02.AntonLilja
{
    class Apartment
    {
        List<Room> rooms = new List<Room>();
        public int NumberOfRooms { get => rooms.Count; }

        public void AddRoomsFromRoomArray(Room[] rooms)
        {
            foreach (var room in rooms)
                AddRoom(room);
        }

        public void AddRoom(Room room) => rooms.Add(room);

        //public static List<Room> GetRoomsWithLightsOn()
        //{

        //}

        //public static List<Room> GetLargestRooms()
        //{

        //}

        public void ListRooms()
        {
            foreach (var item in rooms)
            {
                Console.WriteLine(item);
            }
        }
    }
}
