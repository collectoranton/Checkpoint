﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Checkpoint02.AntonLilja
{
    class App
    {
        public static void Run()
        {
            while (true)
            {
                WriteLineColor("Ange rum i lägenheten:", ConsoleColor.White);

                var input = ReadLineColor(ConsoleColor.Gray);

                if (StringIsExit(input))
                    break;

                var apartment = new Apartment();

                apartment.AddRoomsFromRoomArray(RoomParser.RoomArrayFromString(input));

                apartment.ListRooms();
            }

        }

        public static bool StringIsExit(string input) => (input.Trim().ToLower() == "exit") ? true : false;

        public static void WriteLineColor(string writeLine, ConsoleColor color)
        {
            var initialColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            Console.WriteLine(writeLine);
            Console.ForegroundColor = initialColor;
        }

        public static string ReadLineColor(ConsoleColor color)
        {
            var initialColor = Console.ForegroundColor;
            Console.ForegroundColor = color;
            var input = Console.ReadLine();
            Console.ForegroundColor = initialColor;
            return input;
        }
    }
}
